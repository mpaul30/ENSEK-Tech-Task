import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';
import { MeterReadingService } from './services/meter-reading.service';

@Component({
  selector: 'app-meter-upload',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './meter-upload.component.html',
  styleUrls: ['./meter-upload.component.css']
})
export class MeterUploadComponent {
  selectedFile: File | null = null;
  invalidEntries: any[] = [];

  constructor(private meterService: MeterReadingService) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  onUpload() {
    if (!this.selectedFile) return;

    this.meterService.uploadCsv(this.selectedFile).subscribe({
      next: (res) => {
        this.invalidEntries = res.invalidEntries;
        alert(`Upload complete. Valid: ${res.validCount}, Invalid: ${res.invalidCount}`);
      },
      error: (err) => {
        alert('Upload failed.');
        console.error(err);
      }
    });
  }
downloadInvalid() {
    // this.http.get('https://localhost:7230/api/MeterReadings/download-invalid', {
    //   responseType: 'blob'
    // }).subscribe(blob => {
    //   const url = window.URL.createObjectURL(blob);
    //   const a = document.createElement('a');
    //   a.href = url;
    //   a.download = 'InvalidEntries.csv';
    //   a.click();
    //   window.URL.revokeObjectURL(url);
    // });
  }


}
