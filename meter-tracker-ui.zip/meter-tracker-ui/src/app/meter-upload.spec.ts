import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeterUpload } from './meter-upload';

describe('MeterUpload', () => {
  let component: MeterUpload;
  let fixture: ComponentFixture<MeterUpload>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MeterUpload]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MeterUpload);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
