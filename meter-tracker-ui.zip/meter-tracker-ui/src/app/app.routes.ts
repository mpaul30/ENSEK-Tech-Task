import { Routes } from '@angular/router';
import { MeterUploadComponent } from './meter-upload.component';

export const routes: Routes = [
  { path: '', component: MeterUploadComponent },
];