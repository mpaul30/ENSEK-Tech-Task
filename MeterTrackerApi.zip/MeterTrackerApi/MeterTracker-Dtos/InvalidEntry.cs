﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Dtos
{
    public class InvalidEntry
    {
        public string RawData { get; set; } = "";
        public string ErrorMessage { get; set; } = "";
    }
}
