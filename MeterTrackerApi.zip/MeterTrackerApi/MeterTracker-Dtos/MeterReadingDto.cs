﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Dtos
{
    public class MeterReadingDto
    {

            public string? AccountId { get; set; }
            public string? ReadingDate { get; set; }
            public string? ReadingValue { get; set; }
       
    }
}
