﻿using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Dtos.Mapping
{
    public class MeterReadingDtoMap : ClassMap<MeterReadingDto>
    {
        public MeterReadingDtoMap()
        {
            Map(m => m.AccountId).Name("AccountId", "Account Id"); // Accepts these headers
            Map(m => m.ReadingDate).Name("MeterReadingDateTime", "MeterReading DateTime");
            Map(m => m.ReadingValue).Name("MeterReadValue", "MeterRead Value");
        }
    }
}
