﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Dtos.Mapping
{
    public interface ICsvMappingRegister
    {
        void RegisterMaps(CsvContext context);
    }
}
