﻿namespace MeterTracker_Dtos
{
    public class CustomerMicrDetails
    {
     
        public string CustomerID { get; set; }
        public string AccountNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
      
    }
}
