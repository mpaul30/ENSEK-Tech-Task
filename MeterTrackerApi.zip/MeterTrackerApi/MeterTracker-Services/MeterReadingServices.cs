﻿using CsvHelper;
using CsvHelper.Configuration;
using MeterTracker_Dtos;
using MeterTracker_Dtos.Mapping;
using MeterTracker_Models;
using MeterTracker_Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Formats.Asn1;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MeterTracker_Services
{
    public class MeterReadingService : IMeterReadingService
    {
        private readonly IMeterReadingRepository _repo;
        private readonly ICsvMappingRegister _mappingRegister;
        private readonly ILogger<MeterReadingService> _logger;
        public MeterReadingService(IMeterReadingRepository repo, ICsvMappingRegister mappingRegistrar, ILogger<MeterReadingService> logger)
        {
            _repo = repo;
            _mappingRegister = mappingRegistrar;
            _logger = logger;
        }

        /// <summary>
        /// Validate the csv file 
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public async Task<(List<MeterReading>, List<InvalidEntry>)> ProcessCsvAsync(Stream stream)
        {
            var valid = new List<MeterReading>();
            var invalid = new List<InvalidEntry>();
            try
            { 

            using var reader = new StreamReader(stream);
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,
                MissingFieldFound = null,
                PrepareHeaderForMatch = args => args.Header.Trim().ToLower() //This allows case-insensitive and trimmed header matching
            });
            _mappingRegister.RegisterMaps(csv.Context);
            var existingCustomers = (await _repo.GetAllCustomersAsync()).ToHashSet(); //Use this line if you need to get the existing customer data from db
            var existingAccountIds = existingCustomers.Select(c => c.AccountId).ToHashSet();
            var seenThisUpload = new HashSet<int>();
            var records = csv.GetRecords<MeterReadingDto>();
            try
            {
                await foreach (var dto in csv.GetRecordsAsync<MeterReadingDto>())
                {
                    var raw = csv.Context.Parser.RawRecord;
                    string? error = null;

                    if (string.IsNullOrWhiteSpace(dto.AccountId) ||
                        string.IsNullOrWhiteSpace(dto.ReadingDate) ||
                        string.IsNullOrWhiteSpace(dto.ReadingValue))
                        error = "Missing required fields.";
                    else if (!Regex.IsMatch(dto.AccountId, "^\\d{4}$"))
                        error = "MeterId must be a 4-digit numeric value.";
                    else if (!int.TryParse(dto.AccountId, out var accountId))
                        error = "MeterId must be numeric.";
                    else if (!DateTime.TryParse(dto.ReadingDate, out var date))
                        error = "Invalid ReadingDate.";
                    else if (!decimal.TryParse(dto.ReadingValue, out var value))
                        error = "Invalid ReadingValue.";
                    else if (seenThisUpload.Contains((accountId)))
                        error = "Duplicate meter entry (either in upload).";
                     else if (!existingAccountIds.Contains(accountId))
                            error = "Account ID not found in existing customers.";

                    if (error != null)
                    {
                            _logger.LogError("Validation error occurred : {0}" ,error );
                            invalid.Add(new InvalidEntry { RawData = raw, ErrorMessage = error });
                    }
                    else
                    {
                        
                        valid.Add(new MeterReading { AccountId = Convert.ToInt32(dto.AccountId), MeterReadingDateTime = Convert.ToDateTime(dto.ReadingDate), MeterReadValue = Convert.ToDecimal(dto.ReadingValue) });
                        seenThisUpload.Add(Convert.ToInt32(dto.AccountId));
                    }
                }
            }
            catch (HeaderValidationException ex)
            {
                _logger.LogError(ex, "Header validation failed.");
                throw;
            }
            catch (System.MissingFieldException ex)
            {
                _logger.LogError(ex, "Field missing in CSV.");
                throw;
            }

            await _repo.SaveValidReadingsAsync(valid);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing CSV.");
            throw;
        }

            return (valid, invalid);
        }

        /// <summary>
        /// Added this code just as reference for future if needed a downloadable feature
        /// </summary>
        /// <param name="invalidEntries"></param>
        /// <returns></returns>
        public async Task<byte[]> GenerateInvalidCsvAsync(List<InvalidEntry> invalidEntries)
        {

        try
        {
            using var mem = new MemoryStream();
            using var writer = new StreamWriter(mem);
            using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);

            csv.WriteHeader<InvalidEntry>();
            await csv.NextRecordAsync();

            foreach (var entry in invalidEntries)
            {
                csv.WriteRecord(entry);
                await csv.NextRecordAsync();
            }

            await writer.FlushAsync();
            return mem.ToArray();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating invalid CSV file.");
            throw;
        }
}

    }
}
