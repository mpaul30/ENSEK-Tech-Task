﻿using MeterTracker_Dtos;
using MeterTracker_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Services
{
    public interface IMeterReadingService
    {
        Task<byte[]> GenerateInvalidCsvAsync(List<InvalidEntry> lastInvalidEntries);
        Task<(List<MeterReading>, List<InvalidEntry>)> ProcessCsvAsync(Stream stream);
    }
}
