﻿using CsvHelper;
using MeterTracker_Dtos;
using MeterTracker_Dtos.Mapping;
using MeterTracker_Models;
using MeterTracker_Repository;
using MeterTracker_Services;
using Microsoft.Extensions.Logging;
using Moq;
using System.Globalization;
using System.Text;
using Xunit;
using Assert = Xunit.Assert;

namespace MeterTracker_Tests
{
    [TestClass]
    // --- Tests/MeterReadingServiceTests.cs ---
    public class MeterReadingServiceTests
    {

        [Fact]
        public void CanReadMeterReadingsFromCsv()
        {
            var csvData = @"AccountId,MeterReadingDateTime,MeterReadValue
                            1,2024-06-01T10:00:00,123.45
                            2,2024-06-02T10:00:00,234.56";

            using var reader = new StringReader(csvData);
            using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

            csv.Context.RegisterClassMap<MeterReadingDtoMap>(); // Optional, but good practice

            var records = csv.GetRecords<MeterReadingDto>().ToList();

            Assert.Equal(2, records.Count);
           
        }

        [Fact]
        public async Task ProcessCsvAsync_ParsesValidAndInvalidRowsCorrectly()
        {
            var mockRepo = new Mock<IMeterReadingRepository>();
            var logger = Mock.Of<ILogger<MeterReadingService>>();

            // Mock one valid customer
            var existingCustomers = new List<Customer>
            {
                new Customer { AccountId = 1234, FirstName = "Test", LastName = "User" }
            };

            mockRepo
                .Setup(r => r.GetAllCustomersAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(existingCustomers);

            mockRepo
                .Setup(r => r.SaveValidReadingsAsync(It.IsAny<List<MeterReading>>()))
                .Returns(Task.CompletedTask);

            // Test CSV (1 valid row, 1 invalid)
            var csvData = "MeterId,ReadingDate,ReadingValue\n1234,2025-06-01,100.5\nXYZ,invalidDate,abc";
            var csvStream = new MemoryStream(Encoding.UTF8.GetBytes(csvData));

            // Setup service with mapper
            var mappingRegister = new MeterReadingDtoMappingRegister(); // this must register MeterReadingDtoMap
            var service = new MeterReadingService(mockRepo.Object, mappingRegister, logger);

            // Act
            var (valid, invalid) = await service.ProcessCsvAsync(csvStream);

            // Assert
            Assert.Single(valid);
            Assert.Single(invalid);
        }

        [Fact]
        public async Task GenerateInvalidCsvAsync_ReturnsCsvFile()
        {
            var service = new MeterReadingService(Mock.Of<IMeterReadingRepository>(), new MeterReadingDtoMappingRegister(), Mock.Of<ILogger<MeterReadingService>>());
            var invalid = new List<InvalidEntry>
        {
            new InvalidEntry { RawData = "bad data", ErrorMessage = "Missing fields" }
        };

            var result = await service.GenerateInvalidCsvAsync(invalid);

            Assert.NotNull(result);
            Assert.True(result.Length > 0);
        }
    }
}
