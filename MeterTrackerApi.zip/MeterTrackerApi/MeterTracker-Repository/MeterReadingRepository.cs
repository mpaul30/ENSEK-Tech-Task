﻿using MeterTracker_Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;




namespace MeterTracker_Repository
{
    public class MeterReadingRepository : IMeterReadingRepository
    {
        private readonly IConfiguration _configuration;
        private readonly AppDbContext _context;
        private readonly ILogger<MeterReadingRepository> _logger;
        private readonly string _connectionString;
        public MeterReadingRepository( IConfiguration configuration, AppDbContext context, ILogger<MeterReadingRepository> logger)
        {
            _configuration = configuration;
            _context = context;
            _logger = logger;
            _connectionString = configuration.GetConnectionString("AzureSQLConnectionString")
           ?? throw new ArgumentNullException(nameof(configuration), "Connection string not found.");
        }

        /// <summary>
        /// Get existing customer data from database, so that it can validate against the file getting uploaded
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Customer>> GetAllCustomersAsync(CancellationToken cancellationToken = default)
        {
            var customers = new List<Customer>();

            try
            {
                await using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync(cancellationToken);

                await using var command = new SqlCommand(DbConstants.StoredProcedures.GetAllCustomers, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                await using var reader = await command.ExecuteReaderAsync(cancellationToken);

                while (await reader.ReadAsync(cancellationToken))
                {
                    customers.Add(new Customer
                    {
                        AccountId = reader.GetInt32(reader.GetOrdinal("AccountId")),
                        FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                        LastName = reader.GetString(reader.GetOrdinal("LastName"))
                    });
                }

                _logger.LogInformation("Successfully retrieved {Count} customers.", customers.Count);
            }
            catch (SqlException sqlEx)
            {
                _logger.LogError(sqlEx, "A SQL error occurred while retrieving customers.");
                throw; // or throw a custom repository-level exception
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred in GetAllCustomersAsync.");
                throw;
            }

            return customers;
        }


        /// <summary>
        /// Save valid meter reading to azure database
        /// </summary>
        /// <param name="readings"></param>
        /// <returns></returns>
        public async Task SaveValidReadingsAsync(List<MeterReading> readings)
        {
            _logger.LogInformation("Starting SaveValidReadingsAsync with {Count} readings", readings.Count);

            try
            {
                using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();
                _logger.LogInformation("SQL connection opened successfully.");

                using var command = new SqlCommand(DbConstants.StoredProcedures.ReplaceMeterReadings, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                var table = new DataTable();
                table.Columns.Add("AccountId", typeof(string));
                table.Columns.Add("MeterReadingDateTime", typeof(DateTime));
                table.Columns.Add("MeterReadValue", typeof(decimal));

                foreach (var reading in readings)
                {
                    table.Rows.Add(reading.AccountId, reading.MeterReadingDateTime, reading.MeterReadValue);
                }

                var param = command.Parameters.AddWithValue("@Readings", table);
                param.SqlDbType = SqlDbType.Structured;
                param.TypeName = "MeterReadingType";

                await command.ExecuteNonQueryAsync();
                
            }
            catch (SqlException ex)
            {
                _logger.LogError(ex, "SQL error while replacing meter readings.");
                throw; // Re-throw for controller or global error handler
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error while replacing meter readings.");
                throw;
            }
            _logger.LogInformation("Stored procedure ReplaceMeterReadings executed successfully.");
        }


    }

}
