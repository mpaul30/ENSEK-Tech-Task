﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Repository
{
    public static class DbConstants
    {
        public static class StoredProcedures
        {
            public const string GetAllCustomers = "GetAllCustomers";
            public const string ReplaceMeterReadings = "ReplaceMeterReadings";
          
        }
    }
}
