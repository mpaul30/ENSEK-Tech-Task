﻿using MeterTracker_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeterTracker_Repository
{
    public interface IMeterReadingRepository
    {
        Task<IEnumerable<Customer>> GetAllCustomersAsync(CancellationToken cancellationToken = default);
        Task SaveValidReadingsAsync(List<MeterReading> readings);
    }
}
