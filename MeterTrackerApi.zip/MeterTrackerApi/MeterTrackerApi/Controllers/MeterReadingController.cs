﻿using Newtonsoft.Json;
using System.Formats.Asn1;
using System.Text.Json;
using MeterTracker_Dtos;
using MeterTracker_Services;
using MeterTrackerApi.Error;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MeterTrackerApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeterReadingController : ControllerBase
    {
        private readonly IMeterReadingService _meterReadingService;
        private readonly ILogger<MeterReadingController> _logger;
        private readonly IConfiguration _configuration;
        private static List<InvalidEntry> _lastInvalidEntries = new();

        public MeterReadingController(IMeterReadingService meterReadingService, ILogger<MeterReadingController> logger, IConfiguration configuration)
        {
            _meterReadingService = meterReadingService;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _configuration = configuration;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest("File required");

            try
            {
                _logger.LogInformation(" Upload meter reading request received at {Time}", DateTime.UtcNow);
                var (valid, invalid) = await _meterReadingService.ProcessCsvAsync(file.OpenReadStream());
                _lastInvalidEntries = invalid;
                return Ok(new { ValidCount = valid.Count, InvalidCount = invalid.Count, InvalidEntries = invalid });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Upload failed");
                return StatusCode(500, "Internal server error while processing CSV upload");
            }
        }


        [HttpGet("download-invalid")]
        public async Task<IActionResult> DownloadInvalid()
        {
            try
            {
                if (_lastInvalidEntries == null || !_lastInvalidEntries.Any())
                    return NotFound("No invalid entries to download");

                var csvBytes = await _meterReadingService.GenerateInvalidCsvAsync(_lastInvalidEntries);
                return File(csvBytes, "text/csv", "InvalidEntries.csv");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to download invalid entries");
                return StatusCode(500, "Internal server error while downloading invalid entries");
            }
        }
    }
}
