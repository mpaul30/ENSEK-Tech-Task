﻿namespace MeterTrackerApi.Error
{
    public class ApiException
    {
        //public ApiException(int statusCode, string message = null, string details = null, bool? isSuccess = null) : base(statusCode, message, isSuccess)
        //{
        //    Details = details;
        //}

        public string Details { get; set; }
    }
}
