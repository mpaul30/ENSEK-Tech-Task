﻿namespace MeterTrackerApi.Error
{
    public class ApiResponse
    {
        public ApiResponse(int statusCode, string message = null, bool? isSuccess = null)
        {
            StatusCode = statusCode;
            Message = message ?? GetDefaultMessageForStatusCode(statusCode);
            IsSuccess = isSuccess ?? true;
        }

        public int StatusCode { get; set; }
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
        public object Result { get; set; }

        private string GetDefaultMessageForStatusCode(int statusCode)
        {
            return statusCode switch
            {
                200 => "Ok",
                400 => "A bad request, you have made",
                403 => "Access denined invalid credentials  ",
                401 => "Authorized, you are not",
                404 => "Resource found, it was not",
                500 => "Something went wrong !!!",
                _ => null
            };
        }
    }
}
